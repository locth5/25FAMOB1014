package lab1;

import java.util.Scanner;

public class TPB2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập các hệ số a, b, c
        System.out.print("Nhập hệ số a: ");
        double a = scanner.nextDouble();

        System.out.print("Nhập hệ số b: ");
        double b = scanner.nextDouble();

        System.out.print("Nhập hệ số c: ");
        double c = scanner.nextDouble();

        // Tính delta
        double delta = b * b - 4 * a * c;

        // Tính căn delta
        if (delta < 0) {
            System.out.println("Delta < 0, phương trình vô nghiệm thực.");
        } else {
            double canDelta = Math.sqrt(delta);
            System.out.println("Delta = " + delta);
            System.out.println("Căn delta = " + canDelta);
        }
    }

}
