package lab1;

import java.util.Scanner;

public class lab1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập số nguyên tố
        System.out.println("Nhap nguyen tu thu nhat:");
        int so1 = sc.nextInt();

        // Nhập số nguyên tố thứ hai
        System.out.println("Nhap nguyen tu thu hai:");
        int so2 = sc.nextInt();

        // Nhập số nguyến tố thứ ba
        System.out.println("Nhap nguyen tu thu ba:");
        int so3 = sc.nextInt();

        // ép chuyển sang kiểu double
        Double trungbinh = (double) (so1 + so2 + so3) / 3;

        // Xuất kết quả
        System.out.println("Trung binh cong cua 3 so la:" + trungbinh);
    }
}
