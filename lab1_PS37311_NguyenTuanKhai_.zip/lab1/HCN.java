package lab1;

import java.util.Scanner;

public class HCN {
    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);

        // Nhập chiều dài và chiều rộng
        System.out.print("Nhập chiều dài: ");
        double chieuDai = Sc.nextDouble();

        System.out.print("Nhập chiều rộng: ");
        double chieuRong = Sc.nextDouble();

        // Tính chu vi, diện tích và cạnh nhỏ
        double chuVi = 2 * (chieuDai + chieuRong);
        double dienTich = chieuDai * chieuRong;
        double canhNho = Math.min(chieuDai, chieuRong);

        // Xuất kết quả
        System.out.println("Chu vi hình chữ nhật: " + chuVi);
        System.out.println("Diện tích hình chữ nhật: " + dienTich);
        System.out.println("Cạnh nhỏ nhất: " + canhNho);
    }

}