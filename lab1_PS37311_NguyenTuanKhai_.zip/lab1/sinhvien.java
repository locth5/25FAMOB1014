package lab1;

import java.util.Scanner;

public class sinhvien {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhập họ và  tên");
        String hoTen = sc.nextLine();

        System.out.print("Nhập điểm trung bình ");
        double diemTB = sc.nextDouble();

        System.out.print("Họ và tên: " + hoTen + ", Điểm trung bình: " + diemTB);
        sc.close();
    }
}
